<?php
$host = mysqli_connect("localhost","root","");
$db = mysqli_select_db($host, "aksesoris_motor");
?>