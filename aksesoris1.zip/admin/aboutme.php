<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" href="css/styleeee.css" type="text/css">
		<link href="Sunset.jpg" rel="shortcut icon">
	</head>
<body class="body">
	<nav id="nav">
						<a class="link" href="index2.php">home</a>
						<a class="link" href="aboutme.php">about</a>
						<a class="link" href="../admin/halamanlogin.php">Admin</a>
						<a class="link1" href="halamanlogin.php">Log Out</a>
	</nav>
<form id="form l"name="form l" method="post"action="">
		<table width="90%"height=""valign=""cellspcacing="1" border="0" class="tbl">
					<br>
					<tr>
			<td align=""valign="top">
					<br>
					<br>
					<hr>
					<h1 align="center">ABOUT ME</h1>
					<br>
					<a href="index2.php"><input type="Button" value="Kembali"></a>
					<hr>
					<div class="main">
						<div class="img"></div>
						<h1>PT SPAREPART STORAGE</h1>
						<div class="text">Web Devolover from <strong>Depok, Indonesia</strong></div>
						<br>
						<p align="center">Hai, Selamat datang di perusahaan kecil kami
						<p><img src="img/banner-03.jpg" style="border-radius: 30%; margin-left: 30%" width="40%" height="60%"></p>
						</p>
						<br><br><br><hr>
						<p align="center"><b>Copyright 2020</b></p>
					</div>
					<hr>
					</td>
					<td width="20%"align="top"background="" class="tb2">
						<br>
						<br>
						<hr color="black">
						<hr color="black">
						<hr color="black">
						<asside class="sidebar">
						<div class="widget">
							<h2>TABEL BARANG</h2>
							<a href="tabel.php">KLIK</a>
							</div>
						</asside>
						<hr color="black">
						<hr color="black">
						<hr color="black">
						<asside class="sidebar">
								<div class="widget">
									<h2>RIWAYAT</h2>
									<a href="riwayat.php">KLIK</a>
								</div>
						</asside>


			</td>

		</tr>
		</table>
		</form>
</body>
</html>