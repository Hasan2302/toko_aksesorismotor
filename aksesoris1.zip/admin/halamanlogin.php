<!DOCTYPE html>
<html>
<head>
    <title></title>
        <title></title>
        <link rel="stylesheet" href="css/styleeee.css" type="text/css">
        <link href="Sunset.jpg" rel="shortcut icon">
</head>
<body class="bbddyy" align="center">
    <div class="kotak-login">
        <h1 class="p-login">Silahkan Login</h1>
        <br>
        <form action="proseslogin.php" method="post">
            <label>Username</label>
            <input type="text" name="username" class="form-login" placeholder="Username atau E-Mail .." required="">

            <label>Password</label>
            <input type="password" name="password" class="form-login" placeholder="Password .." required="">

            <input type="submit" class="tombol-login" value="LOGIN">

            <br>
            <br>
        </form>
    </div>
</body>
</html>