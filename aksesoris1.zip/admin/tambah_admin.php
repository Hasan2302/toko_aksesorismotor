<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/styleeee.css">
</head>
<body class="bd2">
</body>
<form action="tb_user.php" method="POST" class="frm3">
<div class="kotak-login">
        <h1 class="p-login">Tambah</h1><a href="tabel.php"><input type="Button" value="Kembali"></a>
        <hr>
        <br>
            <label>Username</label>
            <input type="text" name="username" class="form-login" placeholder="Username .." required="">

            <label>Password</label>
            <input type="text" name="password" class="form-login" placeholder="Password .." required="">

            <input type="submit" class="tombol-login" value="Simpan">
            <input type="reset"  value="RESET">
            <br>
            <br>
            <br><br><br>
    </div>
</form>
</body>
</html>