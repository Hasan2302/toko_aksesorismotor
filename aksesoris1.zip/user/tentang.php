    <link rel="stylesheet" href="../../../assets/css/users/navigasi/tentang.css" type="text/css">
    <link rel="stylesheet" href="../../../assets/font/fontawsome/css/all.css">

    <div class="wrapper-about">
        <h1>Tentang Perusahaan Kami</h1>
        <div class="content-about">
            <h2>Siapa Kami?</h2>
            <p>PT.Indo Truck Pratama Depok 
                untuk Adalah Perusahaan yang menyediakan layanan
                rental/sewa berbagai alat berat untuk pekerjaan
                proyek anda;
                <ul>
                    <li>Excavator</li>
                    <li>Bulldozer</li>
                    <li>Truck</li>
                    <li>Tower Crane</li>
                    <li>Dan lain-lainnya</li>
                </ul>
                <p>Kami telah di percaya oleh berbagai perusahaan
                    untuk beragam pekerjaan.</p>
                <p>Kami juga selalu berupaya memberikan pelayanan
                    terbaik,online,dengan harga sewa yang sangat kompetitif.
                </p>
                <p>Motivasi Kami:Menjadi mitra kerja yang dapat diandalkan,
                    dan ini menjadi komitmen kami.
                </p>
            </p>
        </div>
    </div>