<!DOCTYPE html>
<html>
<head>
    <title></title>
        <title></title>
        <link rel="stylesheet" href="css/styleeee.css" type="text/css">
        <link href="Sunset.jpg" rel="shortcut icon">
</head>
<body class="bbddyy">
    <div class="kotak-login">
        <h1 class="p-login">Account</h1>
        <a href="index2.php"><input type="Button" value="Kembali"></a>
        <br>
        <form action="tmbh.php" method="post" align="center">
            <label>Username</label>
            <input type="text" name="username" class="form-login" placeholder="Username atau E-Mail .." required="">

            <label>Password</label>
            <input type="password" name="password" class="form-login" placeholder="Password .." required="">

            <a href="tabel.php"><input type="Button" value="LEWATI"></a>
            <input type="submit" class="tombol-login" value="LOGIN">

            <br>
            <br>
        </form>
    </div>
</body>
</html>