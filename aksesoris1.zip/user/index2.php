<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" href="css/styleeee.css" type="text/css">
		<link href="Sunset.jpg" rel="shortcut icon">
<!-- 		<img src="RPL.jpg" Width="45px height="60px align="left">
		<img src="SMK 1.jpeg" Width="58px height="60px align="right"> -->
	</head>
<body class="body">
	<nav id="nav">
						<a class="link" href="index2.php">home</a>
						<a class="link" href="aboutme.php">about</a>
						<a class="link" href="../admin/halamanlogin.php">Admin</a>
						
	</nav>
<form id="form l"name="form l" method=""action="">
		<table width="90%"height="" align="center" cellspcacing="1" border="0" class="tbl">
					<br>
					<tr>
			<td align="center">
					<hr>
					<h1 align="">JUAL SPAREPART MOTOR</h1>
					<h1 align="">MURAH DAN BERKUALITAS BAGUS</h1>
					<hr>					
					<br>
					<p align="">
					<img align="" src="img/ufmVYbgS26TOkoUgR3Fg9morMUtpJA_DWO7bGLb9kBv12JLtP80SSW_ISCawZKlNtEmG6N1XZs1ka2LL1sTD8QOomyk0uysVcSqo2_ivX1HR_K0b6aHUK8JhvhGZ0dHGVNw.jpg">
					</p>
					<br>
					<br>
					<br>
					<br>
					<p align="">HUB 	  : 087887314688</p>
					<P align="">E-MAIL : Hasan123@gmail.com</P>
					<hr>
					</td>
					<td width="20%"align=""background="" class="tb2">
					<br>
					<br>
					<hr color="black">
					<hr color="black">
					<hr color="black">
					<asside class="sidebar">
						<div class="widget">
							<h2>TABEL BARANG</h2>
							<a href="masuk.php">KLIK</a>
							</div>
					</asside>
					<hr color="black">
					<hr color="black">
					<hr color="black">
					<asside class="sidebar">
							<div class="widget">
								<h2>RIWAYAT</h2>
								<a href="riwayat.php">KLIK</a>
							</div>
					</asside>

			</td>
		</tr>
		</table>
		</form>
</body>
</html>